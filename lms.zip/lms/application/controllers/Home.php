<?php

class Home extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Homemodel','hm');
		$this->load->model('login_model','lm');

		$this->load->library('session');
		$this->load->library('form_validation');

		if(!$this->session->userdata('user_id'))
			return redirect('User');
	}

	function index()
	{
 		redirect('Home/dashboard');
	}

	function dashboard()
	{
 		$this->load->view('Project/dashboard');
	}

	function book_stock()
	{
		$this->load->view('Project/book_stock');
	}

	function add_author()
	{
		$this->form_validation->set_rules('authorname','Author Name','required|trim|is_unique[authors.name]|regex_match[/^[a-zA-Z ]{5,31}$/]');
		$this->form_validation->set_message('regex_match','Username can contain lower or UPPER case, spaces & 5-31 length');

		$author_name=$this->input->post('authorname');

		if ($this->form_validation->run() == FALSE)
        {
        	$this->session->set_flashdata('error','true');
        	$this->load->view('project/addAuthor',['authorname'=>$author_name]);  // Sending Back Author Name
        }
        else
        {
        	$check = $this->hm->add_author_pub('authors',['name'=>$author_name]);
        	if($check)
        	{
        		$this->session->set_flashdata('error','0');
        	}
        	else
        	{
        		$this->session->set_flashdata('error','1');
        	}

       		$this->load->view('project/addAuthor');
			// redirect('Home/author_list');
        }
	}

	function author_list()
	{
		$arr=$this->hm->get_all_records('authors');

		$result = array();
		$i=1;
		$button='';

		foreach($arr as $key=>$value)
		{
			$button = "<a href='".base_url('Home/update_author/'.$value['id'])."' class='btn btn-info btn-sm' name='editbtn' id='editbtn'>Edit</a>  ";
			$button .= "<a href='".base_url('Home/delete_author/'.$value['id'])."' onclick='return confirm(\"Are you sure?\")' class='btn btn-danger btn-sm' name='deletebtn' id='deletebtn'>Delete</a>  ";

			// DataTable takes Data as Multi-Dimensional Array
			$result['data'][] = array(		
					$i++,
					$value['name'],
					$button
			);		
		}

		echo json_encode($result);
	}

	function delete_author($id)
	{

		$result = $this->hm->delete_author_pub('authors',$id);

		// echo "Result: ".$result;
		if($result)
		{
			$this->session->set_flashdata('error','delete');
		}
		else
		{
			$this->session->set_flashdata('error','1');
		}

		$this->load->view('project/addAuthor');
	}

	function update_author()
	{
		$id= $this->uri->segment(3);
		$result=$this->hm->get_author_pub_detail('authors',$id);		// id, name

		if(is_array($result))
			$this->load->view('project/addAuthor',['update_data'=>$result]);
		else
		{
			redirect('Home/add_author');
		}
	}

	function update_author_data()
	{
		$data = $this->input->post();		// Form Element as an Array

		$id=$data['author_id'];
		$name=$data['authorname'];

		$this->form_validation->set_rules('authorname','Author Name','required|trim|is_unique[authors.name]|regex_match[/^[a-zA-Z ]{5,31}$/]');
		$this->form_validation->set_message('regex_match','Username can contain lower or UPPER case, spaces & 5-31 length');

		if ($this->form_validation->run() == FALSE)
        {
        	$this->session->set_flashdata('error','true');

        	$result=$this->hm->get_author_pub_detail('authors',$id);
        	$this->load->view('project/addAuthor',['update_data'=>$result]);
        }
        else
        {
        	$result=$this->hm->update_author_pub_data('authors',$id, $name);
			if($result)
			{
				echo "<script>alert('Updated Successfully')</script>";
				redirect("Home/add_author");
			}
			else
			{
				$this->session->set_flashdata('error','1');
				$this->load->view('project/addAuthor');
			}
		}
	}

	function pub_add()
	{
		$this->form_validation->set_rules('publishername','Publisher Name','required|trim|is_unique[publisher.name]|regex_match[/^[a-zA-Z ]{5,31}$/]');
		$this->form_validation->set_message('regex_match','Username can contain lower or UPPER case, spaces & 5-31 length');

		$pub_name=$this->input->post('publishername');

		if ($this->form_validation->run() == FALSE)
        {
        	$this->session->set_flashdata('error','true');
        	$this->load->view('project/addPublisher',['pub_name'=>$pub_name]);  // Sending Back Publisher Name
        }
        else
        {
        	$check = $this->hm->add_author_pub('publisher',['name'=>$pub_name]);
        	if($check)
        	{
        		$this->session->set_flashdata('error','0');
        	}
        	else
        	{
        		$this->session->set_flashdata('error','1');
        	}

       		$this->load->view('project/addPublisher');
			// redirect('Home/author_list');
        }
	}

	function publisher_list()
	{
		$arr=$this->hm->get_all_records('publisher');

		$result = array();
		$i=1;
		$button='';

		foreach($arr as $key=>$value)
		{
			$button = "<a href='".base_url('Home/update_publisher/'.$value['id'])."' class='btn btn-info btn-sm' name='editbtn' id='editbtn'>Edit</a>  ";
			$button .= "<a href='".base_url('Home/delete_publisher/'.$value['id'])."' onclick='return confirm(\"Are you sure?\")' class='btn btn-danger btn-sm' name='deletebtn' id='deletebtn'>Delete</a>  ";

			// DataTable takes Data as Multi-Dimensional Array
			$result['data'][] = array(		
					$i++,
					$value['name'],
					$button
			);		
		}

		echo json_encode($result);
	}

	function delete_publisher($id)
	{
		$result = $this->hm->delete_author_pub('publisher',$id);

		// echo "Result: ".$result;
		if($result)
		{
			$this->session->set_flashdata('error','delete');
		}
		else
		{
			$this->session->set_flashdata('error','1');
		}

		redirect('Home/pub_add');
	}

	function update_publisher($id)
	{
		$id= $this->uri->segment(3);
		$result=$this->hm->get_author_pub_detail('publisher',$id);		// id, name

		if(is_array($result))
			$this->load->view('project/addPublisher',['update_data'=>$result]);
	}

	function update_publisher_data()
	{
		$data = $this->input->post();		// Form Element as an Array

		$id=$data['pub_id'];
		$name=$data['publishername'];

		$this->form_validation->set_rules('publishername','Publisher Name','required|trim|is_unique[publisher.name]|regex_match[/^[a-zA-Z ]{5,31}$/]');
		$this->form_validation->set_message('regex_match','Publisher Name can contain only lower or UPPER case, spaces & 5-31 length');

		if ($this->form_validation->run() == FALSE)
        {
        	$this->session->set_flashdata('error','true');

        	$result=$this->hm->get_author_pub_detail('publisher',$id);
        	$this->load->view('project/addPublisher',['update_data'=>$result]);
        }
        else
        {
        	$result=$this->hm->update_author_pub_data('publisher',$id, $name);
			if($result)
			{
				echo "<script>alert('Updated Successfully')</script>";
				redirect("Home/pub_add");
			}
			else
			{
				$this->session->set_flashdata('error','1');
				$this->load->view('project/addPublisher');
			}
		}
	}

	function add_book()
	{
		$author_list=$this->hm->get_all_records('authors');
		$pub_list=$this->hm->get_all_records('publisher');

		$data['author_list']=$author_list;
		$data['pub_list']=$pub_list;

		$this->load->view('project/addBook',$data);	
	}

	function book_add()
	{
		$this->form_validation->set_rules('book_name','Book Name','required|trim|is_unique[book_list.book_name]');
		$this->form_validation->set_rules('author_name','Author Name','required|trim');
		$this->form_validation->set_rules('publisher_name','Publisher Name','required|trim');
		$this->form_validation->set_rules('price','Price','required|trim|numeric');

		$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');

		if($this->form_validation->run()==false)
		{
			$this->add_book();
		}
		else
		{
			$data=$this->input->post();
			unset($data['book_add']);
			// print_r($data);

			$result=$this->hm->add_author_pub('book_list',$data);
			if($result)
			{
				$this->session->set_flashdata(['msg'=>'<b>Book Added Successfully</b>','class'=>'alert-success']);
			}
			else
				$this->session->set_flashdata(['msg'=>"<b>Error!! Something Went Wrong</b>",'class'=>'alert-danger']);

			redirect('Home/add_book');
			// $this->add_book();
		}
	}

	function book_list()
	{
		// $result=$this->hm->get_all_records('book_list');
		$this->load->view('project/book-list');
	}

	function show_book_list()
	{
		$result=$this->hm->get_all_records('book_list');

		$arr = array();
		$i=1;

		foreach($result as $key=>$value)
		{
			// Dataable takes Data as Multi-Dimensional Array
			$arr['data'][] = array(		
					$i++,
					$value['book_name'],
					$value['author_name'],
					$value['publisher_name'],
					$value['price']
			);		
		}

		echo json_encode($arr);
	}

	function members()
	{
		$this->load->view('Project/members');
	}

	function show_member_list()
	{
		$result=$this->hm->get_all_records('members');

		$arr = array();
		$i=1;

		foreach($result as $key=>$value)
		{
			// Dataable takes Data as Multi-Dimensional Array
			$arr['data'][] = array(		
					$i++,
					$value['name'],
					// $value['address'],
					$value['email'],
					$value['mobile']
			);		
		}

		echo json_encode($arr);
	}

	function add_member()
	{
		$this->load->view('Project/add_member');
	}
	function mem_add()
	{
		$this->form_validation->set_rules('name','Member Name','required|trim|is_unique[publisher.name]|regex_match[/^[a-zA-Z ]{5,31}$/]');
		$this->form_validation->set_rules('address','Address','required|trim');
		$this->form_validation->set_rules('email','Email-ID','required|trim|is_unique[members.email]|valid_email');
		$this->form_validation->set_rules('mobile','Mobile Number','required|trim|is_unique[members.mobile]|numeric|regex_match[/^[0-9]{10}$/]');
		
		$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');

		if($this->form_validation->run() == FALSE)
		{
			$this->load->view('Project/add_member');	
		}
		else
		{
			$data=$this->input->post();
			unset($data['submit']);
			// print_r($data);
			// die();

			$result=$this->hm->add_author_pub('members',$data);
			if($result)
			{
				$this->session->set_flashdata(['msg'=>'<b>New Member Added Successfully</b>','class'=>'alert-success']);
			}
			else
			{
				$this->session->set_flashdata(['msg'=>"<b>Error!! Something Went Wrong</b>",'class'=>'alert-danger']);
			}

			redirect('Home/add_member');

		}
	}

	function issue_submit()
	{
		$this->load->view('Project/issue_submit');
	}
	function book_filter()
	{
		$id=$this->input->post('id');

		$this->form_validation->set_rules('id', 'User ID', 'required|trim|numeric');
		// echo($data);

		if ($this->form_validation->run() == FALSE)
        {
        	$this->session->set_flashdata(['msg'=>validation_errors(), 'class_name'=>'alert-danger']);
            $this->load->view('Project/issue_submit',['userid'=>$id]);
        }
        else
        {
			$result=$this->hm->get_author_pub_detail('members',$id);	// Getting Single-Member Info
			// print_r($result);

			if($result)
			{	
				$book_data= $this->hm->get_all_records('book_list');	// Book-List Records

				$this->load->view('Project/issue_submit',['userid'=>$id,'data'=>$result, 'book_list'=>$book_data]);
			}	
			else
			{
				$this->session->set_flashdata(['msg'=>'User Not Found', 'class_name'=>'alert-danger']);
	        	$this->load->view('Project/issue_submit',['userid'=>$id]);
			}
		}	
	}

	function issue_book()
	{
		$data=$this->input->post();
		// print_r($data);
		// die();

		$user_id=$this->input->post('user_id');
		$book_name=$this->input->post('book_name');

			//  To check whether Issuing Book is already taken or not by Given User-id
		$check_status = $this->hm->check_issue_book_status('issued_books',['user_id'=>$user_id, 'book_name'=>$book_name]);
		// echo $check_status;	

			// One User can have max 2 books
		$member_max_book = $this->hm->check_issue_book_status('issued_books',['user_id'=>$user_id]);
		// echo $member_max_book; die();

		if($check_status >= 1)
		{
			$this->session->set_flashdata(['msg'=>"'$book_name' is already issued to User-Id: $user_id", 'class_name'=>'alert-danger']);
		}
		else if($member_max_book>=2)
		{
			$this->session->set_flashdata(['msg'=>"User-Id: $user_id has met Maximum Books Limit", 'class_name'=>'alert-danger']);
		}
		else
		{
			$check = $this->hm->add_author_pub('issued_books',$data);
			// echo($check);
			if($check==1)
				$this->session->set_flashdata(['msg'=>'Book Issue Successfully', 'class_name'=>'alert-success']);	
			else
				$this->session->set_flashdata(['msg'=>'ERROR!! Book Couldn\'t Issued', 'class_name'=>'alert-danger']);	
		}
		redirect('Home/issue_submit');
	}

	function issue_book_list()
	{
		$issueBook_list = $this->hm->get_all_records('issued_books');
		// print_r($issueBook_list);
		// die();
		
		$this->load->view('project/issue_book_list',['data'=>$issueBook_list]);
	}
	function submit_book()
	{
		$id=$this->uri->segment(3);		// Taking Id
		
		$data=$this->hm->get_author_pub_detail('issued_books',$id);		// Get Info of Issued Books
		unset($data['id']);
		unset($data['user_id']);
		unset($data['address']);
		// print_r($data); die();

		$res=$this->hm->add_author_pub('submit_book',$data);	// Add Issued Book to Submit_Book Table
		// echo $res;
		if($res==1)
		{
			$data=$this->hm->delete_author_pub('issued_books',$id);	// Delete Books from Issued_Books
			$this->session->set_flashdata(['msg'=>"Book Submitted Successfully",'class_name'=>'alert-success']);
		}
		else
		{
			$this->session->set_flashdata(['msg'=>"ERROR!! Book Couldn't Submitted",'class_name'=>'alert-danger']);
		}
		redirect('Home/issue_book_list');	
	}


	function get_author()
	{
		$author=$this->hm->get_all_records('authors');
		$this->load->view('project/author-list',['authors'=>$author]);
	}

	function submitted_book_list()
	{
		$book_list=$this->hm->get_all_records('submit_book');
		$this->load->view('project/submitted_book_list',['book_list'=>$book_list]);
		// $this->load->view('Project/amount&expenses');
	}

	function gen_report()
	{
		$this->load->view('project/report');
	}

	function get_report_info()
	{
		// $person=$this->uri->segment(3);
		// echo $person; die();
		// $table=$this->input->post('table');
		$person=$this->input->post('name');

		// $data=$this->hm->report_generate($person);
		// // print_r($data);
		// // die();
		// echo json_encode($data);

		///////////////////
		$arr=$this->hm->report_generate($person);

		$result = array();
		$i=1;
		// $button='';

		foreach($arr as $key=>$value)
		{
			// $button = "<a href='".base_url('Home/update_author/'.$value['id'])."' class='btn btn-info btn-sm' name='editbtn' id='editbtn'>Edit</a>  ";
			// $button .= "<a href='".base_url('Home/delete_author/'.$value['id'])."' onclick='return confirm(\"Are you sure?\")' class='btn btn-danger btn-sm' name='deletebtn' id='deletebtn'>Delete</a>  ";

			// DataTable takes Data as Multi-Dimensional Array
			$result['data'][] = array(		
					$i++,
					$value['name'],
					$value['book_name'],
					// $button
			);		
		}

		echo json_encode($result);
	}
}

?> 
