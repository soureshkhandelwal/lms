<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Homemodel','hm');
		$this->load->model('login_model','lm');

		$this->load->library('session');
	}

	function index()
	{
		if($this->session->userdata('user_id'))
			return redirect('Home/dashboard');

		$this->load->view('project/homepage');
	}

	function login()
	{
		$un = $this->input->post('user');
		$pass = $this->input->post('pass');
		// die();

		if(!empty($un) && !empty($pass))
		{

			$login_id=$this->lm->verify_login($un,$pass);
			// die;

			if($login_id)
			{
				$this->session->set_userdata(['user_id'=>$login_id, 'username'=>$un]);
				echo 1;
			}
			else
				echo 0;
		}
		else
			redirect('User');
	}

	function logout()
	{
		$this->session->unset_userdata('user_id');
		// $this->session->unset_userdata('username');
		return redirect('User');
	}
}
