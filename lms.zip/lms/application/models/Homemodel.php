<?php

class Homemodel extends CI_Model
{
	function add_author_pub($table,$data)
	{
		$insert_data=$this->db->insert($table,$data);

		if($insert_data)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	function get_all_records($table)
	{
		$q=$this->db->get($table);
		return $q->result_array();
	}

	function get_author_pub_detail($table,$id)
	{
		$q=$this->db->where('id',$id)->get($table);
		return $q->row_array();
	}

	function update_author_pub_data($table,$id,$name)
	{
		$result=$this->db->set('name',$name)->where('id', $id)->update($table);
		return $result;
	}

		// $q=$this->db->where('id',$id)->get($table);

	function delete_author_pub($table, $id)
	{
		$result = $this->db->where('id', $id)->delete($table);
		return $result;
	}

	function check_issue_book_status($table, $arr)
	{
		$result = $this->db->where($arr)->get($table);
		return $result->num_rows();
	}

	function report_generate($name)
	{
		$q=$this->db->select("{$name} AS name , book_name")->get('book_list');
		return $q->result_array();
	}
}

?>