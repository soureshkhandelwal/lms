<?php

class Login_model extends CI_Model
{
	function verify_login($un,$pswd)
	{
		$this->load->database();
		$res=$this->db->query("select * from admin where username='{$un}' and password='{$pswd}' ");

		if($res->num_rows()>0)
		{
			$data=$res->row_array();	// single array of matched record
			// echo "<pre>";
			// print_r($data);
			// echo "</pre>";
			return $data['id'];		// return only ID of Logging User
		}
		else
			return false;
	}
}

?>