<?php 
	define('Title','Add New Author');
	define('active_nav', 'Book Stock Manage');
?>
<?php include('header.php'); ?>

	<div class='container mt-2' style="opacity:0.7;height:100%;width:auto; box-shadow:1px 1px 5px 5px black;background-color: lightblue">
		<div class="row">
			<div class="col-5">
				<h1 class='display-5'>Welcome (<?php echo $this->session->userdata('username') ?>) </h1>				
			</div>
			<div class="col offset-5 mt-3">
				<a class="btn btn-warning" href="<?= base_url('User/logout'); ?>"><i class="fas fa-sign-out-alt"></i> Log Out</a>
			</div>
		</div> 
		<hr>

		<div class='row' style="height: auto;">

			<div class='col-sm-3 border-right border-dark'>
				<?php include 'side_nav_bar.php'; ?>
			</div>

			<div class='col'>
				<div class="row mt-2">
					<div class="col-2">
						<a class="btn btn-danger" href="<?= base_url('home/book_stock'); ?>"><i class="fas fa-angle-double-left"></i> Back</a>
					</div>
					<div class="col-6">
						<h4 class='text-center text-dark' style="font-size:28px;"><b><?php echo Title; ?></b></h4>
					</div>
				</div>

				<hr>

				<?php 
					if(isset($update_data))
					{
						echo form_open('Home/update_author_data');
				?>
						<div class='row'>
							<div class='form-group col-sm-2'>
			                    <label for='authorname' style="font-size:18px;">Author Name</label>
			                </div>
			                <div class='col-sm-5'>
			                	<input type="hidden" name="author_id" id="author_id" value="<?= $update_data['id']; ?>">
			                    <input type='text' id='authorname' class='form-control' placeholder='Edit Author name' value="<?php echo $update_data['name'] ?>" name='authorname'>
			                </div>
			                <div class='col-sm-2'>
			                    <button type='submit' class='btn btn-success btn-sm' name="update_data" value="Update">Update</button>
			                </div>
			            </div>
	            		
	            		<div class="row">
	            			<div class="offset-2" id="alertmsg">

	            		<?php
	            			$msg='';
	            			if($this->session->flashdata('error')!='')
	            			{	
	            				$result=$this->session->flashdata('error');
	            				if($result=='true')
	            				{
									echo validation_errors("<div class='text-danger'>** ", "</div>");
	            					// echo "<div class='text-success'> Author Added Successfully </div>";
	            				}
								else if($result=='update')
									echo "<div class='text-success'> Author Updated Successfully </div>";
	            				else
	            					echo "<div class='text-danger'> ERROR!!! Something went WRONG. </div>";
	            			}
	            		?>

	            			</div>
	            		</div>

				<?php 	echo form_close(); ?>

				<?php
					}
					else
					{
				?>
						<?php echo form_open('Home/add_author'); ?>
							<div class='row'>
								<div class='form-group col-sm-2'>
					                    <label for='authorname' style="font-size:18px;">Add Author</label>
					                </div>
					                <div class='col-sm-5'>
					                    <input type='text' id='authorname' class='form-control' placeholder='Enter Author name' name='authorname' value="<?php if(isset($authorname)) echo $authorname ?>">
					                </div>
					                <div class='col-sm-2'>
					                    <button type='submit' class='btn btn-success' name="add_data">Add</button>
					                </div>
					        </div>

					        <div class="row">
			            		<div class="offset-2" id="alertmsg">
			            		<?php
			            			if($this->session->flashdata('error')!='')
			            			{	
			            				$result=$this->session->flashdata('error');
			            				if($result=='0')
			            				{
			            					$msg= "<div class='text-success'> Author Added Successfully </div>";
			            					// echo "<div class='text-success'> Author Added Successfully </div>";
			            				}
			            				else if($result=='1')
			            					$msg= "<div class='text-danger'> ERROR!!! Something went WRONG. </div>";
			            				else if($result=='delete')
			            					$msg= "<div class='text-dangr text-weight-bold'> Data Deleted Successfully. </div>";
			            				else
			            					$msg= validation_errors("<div class='text-danger'>** ", "</div>");

										echo $msg;
			            			}

			            			
			            		?>
			            	</div>
			            </div>

				<?php echo form_close();
					} 
				?>

				<script type="text/javascript">
					setTimeout($('#alertmsg').fadeOut(3000));
					// setTimeout(function(){
					// 	window.location.href=<?php base_url('Home/add_author'); ?>
					// },5000);
				</script>


				<br>
				<!-- <hr> -->
				<table class='table table-sm' style="width:750px;" id="authortable">
					<thead>
						<tr>
							<th>ID</th>
							<th>Author Name</th>
							<th>Operations</th>
						</tr>
					</thead>
				</table>
			</div>	
		</div>
	</div>

	<script type="text/javascript">

	$(document).ready(function()
	{
		$('#authortable').DataTable({
			"ajax": "<?php echo base_url('Home/author_list'); ?>",
			"order": [],
			"lengthMenu": [[5, 10, 15, 20, -1],[5, 10, 15, 20, "ALL"]],
		});
	});
	</script>        

<?php include('footer.php'); ?>