<?php  
	define('Title','Add Book');
	define('active_nav', 'Book Stock Manage');
?>
<?php include('header.php'); ?>

	<div class='container mt-2' style="opacity:0.7;height:100%;box-shadow:1px 1px 5px 5px black;background-color: lightblue">
		<div class="row">
			<div class="col-5">
				<h1 class='display-5'>Welcome (<?php echo $this->session->userdata('username') ?>) </h1>				
			</div>
			<div class="col offset-5 mt-3">
				<a class="btn btn-warning" href="<?= base_url('User/logout'); ?>"><i class="fas fa-sign-out-alt"></i> Log Out</a>
			</div>
		</div>

		<hr>

		<div class='row' style="height:600px;">

			<div class='col-sm-3 border-right border-dark'>
				<?php include 'side_nav_bar.php'; ?>
			</div>
			
			<div class='col-sm' style="height:auto;">
				<div class="row mt-2">
					<div class="col-2">
						<a class="btn btn-danger" href="<?= base_url('home/book_stock'); ?>"><i class="fas fa-angle-double-left"></i> Back</a>
					</div>
					<div class="col-7">
						<h4 class='text-center' style="font-size:28px;"><b><?php echo Title; ?></b></h4>				
					</div>
				</div>
				<hr>

			<?php 
				if($this->session->flashdata('msg')!='')
				{
					$msg=$this->session->flashdata('msg') ;
					$class=$this->session->flashdata('class') ;
					// if(!empty($msg))
					// {
			?>
					<div class="alert <?php echo $class ?> w-50">
						<?php echo $msg; ?>
					</div>
			<?php
				}	 
			?>
			
			<script type="text/javascript">
				$('.alert-success').fadeOut(6000);
				$('#adding_new_book').trigger('reset');
			</script>
			 
			
			<?php echo form_open('Home/book_add',['id'=>'adding_new_book']); ?>
				<div class='row'>
					<div class='form-group col-sm-3'>
	                    <label for='book' style="font-size:17px;"><b>Book Name</b></label>
	                </div>
	                <div class='col-sm-8'>
	                    <input type='text' id='book' class='form-control w-50' value="<?php echo set_value("book_name"); ?>" placeholder='Book name' name='book_name'>
						<?php echo form_error('book_name'); ?>
	                </div>
	            </div>
	            <div class='row'>
	            	<div class='form-group col-sm-3'>
	                    <label for='book' style="font-size:17px;"><b>Author</b></label>
	                </div>
	                <div class='form-group col-sm-5'>
						<select name='author_name' class='form-control'>
							<option value="" selected disabled>--Select--</option>
						<?php foreach($author_list as $auth_data): ?>
							<option <?php echo set_select('author_name',$auth_data['name']) ?> ><?php echo $auth_data['name'] ?></option>
						<?php endforeach; ?>
						</select>
						<?php echo form_error('author_name'); ?>
					</div>
		        </div>

		        <div class='row'>
	            	<div class='form-group col-sm-3'>
	                    <label for='book' style="font-size:17px;"><b>Publisher</b></label>
	                </div>
	                <div class='form-group col-sm-5'>
						<select name='publisher_name' class='form-control'>
							<option value="" selected disabled>--Select--</option>
						<?php foreach($pub_list as $pub_data): ?>
							<option <?php echo set_select('publisher_name',$pub_data['name']) ?> ><?php echo $pub_data['name'] ?></option>
						<?php endforeach; ?>
						</select>
						<?php echo form_error('publisher_name'); ?>
					</div>
		        </div>

	            <div class='row'>
					<div class='form-group col-sm-3'>
	                    <label for='book' style="font-size:17px;"><b>Price</b></label>
	                </div>
	                <div class='col-sm-8'>
	                    <input type='number' id='book' class='form-control w-50' value="<?php echo set_value('price'); ?>" placeholder='Book-Price' name='price'>
						<?php echo form_error('price'); ?>
	                </div>
	            </div>
	            <div class='row'>
	            	<div class='col-sm-12 text-center'>
						<button type='submit' class='btn btn-success' name='book_add'>Book-Add</button>
					</div>
				</div> 	
			<?php echo form_close(); ?>
		<a class="btn btn-secondary" href="<?= base_url('Home/book_list'); ?>"><i class="fas fa-sign-out-alt"></i> Book List</a>


			</div>	
		</div>
	</div>  

<?php include('footer.php'); ?>
