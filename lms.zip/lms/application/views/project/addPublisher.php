<?php  
	define('Title','Add New Publisher');
	define('active_nav', 'Book Stock Manage');
?>
<?php include('header.php'); ?>

	<div class='container mt-2' style="opacity:0.7;height:100%;box-shadow:1px 1px 5px 5px black;background-color: lightblue">
		<div class="row">
			<div class="col-5">
				<h1 class='display-5'>Welcome (<?php echo $this->session->userdata('username') ?>) </h1>				
			</div>
			<div class="col offset-5 mt-3">
				<a class="btn btn-warning" href="<?= base_url('User/logout'); ?>"><i class="fas fa-sign-out-alt"></i> Log Out</a>
			</div>
		</div>

		<hr>

		<div class='row'>
			<div class='col-sm-3 border-right border-dark'>
				<?php include 'side_nav_bar.php'; ?>
			</div>
			<div class='col-sm' style="height:auto;">
				<div class="row mt-2">
					<div class="col-2">
						<a class="btn btn-danger" href="<?= base_url('home/book_stock'); ?>"><i class="fas fa-angle-double-left"></i> Back</a>
					</div>
					<div class="col-7">
						<h4 class='text-center' style="font-size:28px;"><b><?php echo Title; ?></b></h4>				
					</div>
				</div>
				<hr>

				<?php 
				if(isset($update_data)) 
				{
					// print_r($rec_single);
					echo form_open('Home/update_publisher_data');
				?>
						<div class='row'>
							<div class='form-group col-sm-3'>
			                    <label for='publishername' style="font-size:20px;">Publisher Name</label>
			                </div>
			                <div class='col-sm-5'>
			                    <input type='text' id='publishername' class='form-control' value="<?php echo $update_data['name'] ?>" name='publishername'>
			                    <input type="hidden" name="pub_id" value="<?php echo $update_data['id'] ?>" >
			                </div>
			                <div class='col-sm-2'>
			                    <button type='submit' class='btn btn-success'>Update</button>
			                </div>
			            </div>

						<div class="row">
			        		<div id="alertmsg">
			        		<?php
			        			// $msg='';
			        			if($this->session->flashdata('error')!='')
			        			{	
			        				$result=$this->session->flashdata('error');
			        				if($result=='1')
			        					$msg= "<div class='text-danger'> ERROR!!! Something went WRONG. </div>";
			        				else if($result=='delete')
			        					$msg= "<div class='text-warning'><b> Data Deleted Successfully </b> </div>";
			        				else
			        				{
			        					$msg= validation_errors("<div class='text-danger'>** ", "</div>");
			        				}

									echo $msg;
			        			}
			        		?>
					        </div>
					   	</div>

				<?php echo form_close();
				}
				
				else
				{
				?>
					<?php echo form_open('Home/pub_add'); ?>
					<div class='row'>
						<div class='form-group col-sm-3'>
		                    <label for='publishername' style="font-size:20px;">Add Publisher</label>
		                </div>
		                <div class='col-sm-5'>
		                    <input type='text' id='publishername' class='form-control' placeholder='Enter Publisher name' name='publishername' value="<?php if(isset($pub_name)) echo $pub_name ?>">
		                </div>
		                <div class='col-sm-2'>
		                    <button type='submit' class='btn btn-success'>Add</button>
		                </div>
		            </div>

					<div class="row">
		        		<div id="alertmsg">
		        		<?php
		        			// $msg='';
							if($this->session->flashdata('error')!='')
							{	
								$result=$this->session->flashdata('error');
								if($result=='0')
								{
									$msg= "<div class='text-success'> Publisher Added Successfully </div>";
								}
								else if($result=='1')
									$msg= "<div class='text-danger'> ERROR!!! Something went WRONG. </div>";
								else if($result=='delete')
									$msg= "<div class='text-dangr text-weight-bold'> Data Deleted Successfully. </div>";
								else
									$msg= validation_errors("<div class='text-danger'>** ", "</div>");

								echo $msg;
		        			}	
		        		?>
				        </div>
				   	</div>

					<?php echo form_close(); ?>

					<script type="text/javascript">
						setTimeout($('#alertmsg').fadeOut(3000));
					</script>

				<?php  } ?>
				<hr>

				<table class='table table-sm' style="width:100%;" id="publishertable">
					<thead>
						<tr>
							<td>S.No.</td>
							<!-- <th>ID</th> -->
							<th>Publisher Name</th>
							<th>Operations</th>
						</tr>
					</thead>
					
				</table>

			</div>	

		</div>
	</div>   

	<script type="text/javascript">
		$('#publishertable').DataTable({
			"ajax": "<?php echo base_url('Home/publisher_list'); ?>",
			"order": [],
			"lengthMenu": [[5, 10, 15, 20, -1],[5, 10, 15, 20, "ALL"]],
		});
	</script>     

<?php include('footer.php'); ?>
