<?php 
	define('Title','Add Member');
	define('active_nav', 'Member');
?>
<?php include('header.php'); ?>

	<div class='container mt-2' style="opacity:0.7;height:100%;box-shadow:1px 1px 5px 5px black;background-color: lightblue">
		<<div class="row">
			<div class="col-5">
				<h1 class='display-5'>Welcome (<?php echo $this->session->userdata('username') ?>) </h1>				
			</div>
			<div class="col offset-5 mt-3">
				<a class="btn btn-warning" href="<?= base_url('User/logout'); ?>"><i class="fas fa-sign-out-alt"></i> Log Out</a>
			</div>
		</div>

		<hr>
		
		<div class='row' style="height: 500px;">
			
			<div class='col-sm-3 border-right border-dark'>
				<?php include 'side_nav_bar.php'; ?>
			</div>

			<div class='col-sm' style="height:auto;">
				<div class="row">	
				<div class="col-3">
						<a class="btn btn-secondary" href="<?= base_url('home/members'); ?>"><i class="fas fa-list"></i> Member List</a>
					</div>		
					<div class="col-3">
						<h4 class='text-center text-dark' style="font-size:28px;"><b><?php echo Title; ?></b></h4>				
					</div>
				</div>
				<!-- <hr> -->

				<?php 
				if($this->session->flashdata('msg')!='')
				{
					$msg=$this->session->flashdata('msg') ;
					$class=$this->session->flashdata('class') ;
					// if(!empty($msg))
					// {
				?>
						<div class="alert <?php echo $class ?> w-50">
							<?php echo $msg; ?>
						</div>
				<?php
					}	 
				?>
				
				<script type="text/javascript">
					$('.alert-success').fadeOut(6000);
					$('#add_new_member').trigger('reset');
				</script>

				<?php echo form_open('Home/mem_add',['id'=>'add_new_member']); ?>
				<table class="table table-sm w-75 mt-3">
					<tr>
						<td><b>Name</b></td>
						<td><input type='text' name='name' id="name" value="<?php echo set_value("name"); ?>" placeholder="Enter Name" class='form-control'></td> 
					</tr>

					<?php if(form_error('name')) { ?>
					<tr>	<td></td>	<td><?php echo form_error('name'); ?></td>	</tr> 
					<?php } ?>

					<tr>
						<td><b>Address</b></td>
						<td><input type='text' name='address' id="address" value="<?php echo set_value("address"); ?>" placeholder="Enter Address" class='form-control'></td> 
					</tr>

					<?php if(form_error('address')) { ?>
					<tr>	<td></td>	<td><?php echo form_error('address'); ?></td>	</tr> 
					<?php } ?>

					<tr>
						<td><b>Email Address</b></td>
						<td><input type='text' name='email' id="email" value="<?php echo set_value("email"); ?>" placeholder="Enter Email Id" class='form-control'></td>
					</tr>

					<?php if(form_error('email')) { ?>
					<tr>	<td></td>	<td><?php echo form_error('email'); ?></td>	</tr> 
					<?php } ?>

					<tr>
						<td><b>Mobile No</b></td>
						<td><input type='text' name='mobile' id="mobile" value="<?php echo set_value("mobile"); ?>" placeholder="Enter Mobile No" class='form-control'></td>
					</tr>	

					<?php if(form_error('mobile')) { ?>
					<tr>	<td></td>	<td><?php echo form_error('mobile'); ?></td>	</tr> 
					<?php } ?>

					<tr>
						<td></td>
						<td>
							<button class="btn btn-success" type="submit" name="submit">Add</button>
						</td>
					</tr>
				</table>
				<?php echo form_close(); ?>
			</div>
		</div>
	</div>        

<?php include('footer.php'); ?>
