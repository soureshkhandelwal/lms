<?php include('header.php'); ?>

	<div class='container w-75 mt-5' style="opacity:0.7;height:100%;box-shadow:1px 1px 5px 5px black;background-color: lightblue">
		<!-- <h2 class='text-center font-weight-bold text-danger'>Admin Home</h2>  <hr> -->
		<h1 class='display-5'>Welcome Admin</h1>  <hr>
		<div class='row' style="height:400px;">
			<div class='col-sm-3 border-right border-dark'>
				<nav class='nav flex-column nav-pills'>
			             <a  href="<?= base_url('home/dashboard'); ?>" 
			            	class='nav-link text-success font-weight-bold p-3'>Dashboard</a>

			            <a href="<?= base_url('home/book_stock'); ?>" 
			            class='nav-link text-success font-weight-bold p-3'>Book Stock Manage</a>

			            <a href="<?= base_url('home/issue_submit'); ?>"
			             class='nav-link text-success font-weight-bold p-3'>Book Issue & Submit</a>

			            <a href="<?= base_url('home/members'); ?>"
			             class='nav-link text-success font-weight-bold p-3'>Members</a>

			            <a class='nav-link text-success font-weight-bold p-3 active'>Amount & Expenses</a>
			    </nav>
			</div>
			<div class='col-sm'>
				<h3 class='text-center text-secondary'>Amount_Expenses</h3> <hr>
			</div>
		</div>
	</div>        

<?php include('footer.php'); ?>
