<?php
define('Title', 'Book-List');
define('active_nav', 'Book Stock Manage');
?>
<?php include('header.php'); ?>

	<div class='container mt-2' style="opacity:0.7;height:90%;box-shadow:1px 1px 5px 5px black;background-color: lightblue">
		<div class="row">
			<div class="col-5">
				<h1 class='display-5'>Welcome (<?php echo $this->session->userdata('username') ?>) </h1>  <hr>				
			</div>
			<div class="col offset-5 mt-3">
				<a class="btn btn-warning" href="<?= base_url('User/logout'); ?>"><i class="fas fa-sign-out-alt"></i> Log Out</a>
			</div>
		</div>

		<div class='row'>
			<div class='col-sm-3'>
				<?php include 'side_nav_bar.php' ?>
			</div>
				
			<div class='col-sm border-left border-dark' style="height:100%;">
				<div class="row mt-2">
					<div class="col-2">
						<a class="btn btn-danger" href="<?= base_url('home/book_stock'); ?>"><i class="fas fa-angle-double-left"></i> Back</a>
					</div>
					<div class="col-6">
						<h4 class='text-center' style="font-size:28px;"><b><?php echo Title; ?></b></h4>				
					</div>
					<div class="col offset-1">
						<a class="btn btn-secondary" href="<?= base_url('Home/add_book'); ?>"><i class="fas fa-plus"></i> Add Book</a>
					</div>
				</div>

				<hr>

				<table class='table' style="width: 800px;" id="booklist_table">
					<thead>
						<tr>
							<th>ID</th>
							<th>Book-Name</th>
							<th>Author Name</th>
							<th>Publisher Name</th>
							<th>Price</th>
						</tr>
					</thead>
				</table>	
	</div>        

	<script type="text/javascript">

	$(document).ready(function()
	{
		$('#booklist_table').DataTable({
			"ajax": "<?php echo base_url('Home/show_book_list'); ?>",
			"order": [],
			"lengthMenu": [[5, 10, 15, 20, -1],[5, 10, 15, 20, "ALL"]],
		});
	});
	</script> 

<?php include('footer.php'); ?>
