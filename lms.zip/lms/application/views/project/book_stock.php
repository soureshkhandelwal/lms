<?php  
	define('Title','Add New Publisher');
	define('active_nav', 'Book Stock Manage');
?>
<?php include('header.php'); ?>

	<div class='container mt-2' style="opacity:0.8;height:auto;box-shadow:1px 1px 5px 5px black;background-color: lightblue">
		<h1 class='display-5'>Welcome (<?php echo $this->session->userdata('username') ?>) </h1>  <hr>

		<div class='row' style="height:400px;">
			<div class='col-sm-3 border-right border-dark'>
				<?php include 'side_nav_bar.php'; ?>
			</div>
			<div class='col-sm' style="height:auto;">
				<h3 class='text-center text-secondary'>Book Stock Manage</h3> <hr>
				    <ul class='list-inline text-center'>
			            <li class='list-inline-item'>
			            	<ul style='font-size:18px'>
			            		<li class='p-2 font-weight-bold'>
			            			 <a href="<?= base_url('home/add_author'); ?>">Add Author</a> </li>
			            		<li class='p-2 font-weight-bold'> 
			            			<a href="<?= base_url('home/add_book'); ?>">Add Book</a> </li>
			            	</ul>
			            </li>

			            <li class='list-inline-item ml-5'>
			            	<ul style='font-size:18px;'>
			            		<li class='p-2 font-weight-bold'> 
			            			<a href="<?= base_url('home/pub_add'); ?>">Add Publisher</a> </li>
			            		<li class='p-2 font-weight-bold'> 
			            			<a href="<?= base_url('home/book_list'); ?>">Book List</a> </li>
			            	</ul>
			            </li>

		       		</ul>
			</div>
		</div>
	</div>        

<?php include('footer.php'); ?>
