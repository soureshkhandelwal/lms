<?php 
	define('Title','Welcome');
	define('active_nav', 'Dashboard');
?>
<?php include('header.php'); ?>

	<div class='container mt-2' style="opacity:0.7;height:100%;box-shadow:1px 1px 5px 5px black;background-color: lightblue;">
	<div class="row">
			<div class="col-5">
				<h1 class='display-5'>Welcome (<?php echo $this->session->userdata('username') ?>) </h1>				
			</div>
			<div class="col offset-5 mt-3">
				<a class="btn btn-warning" href="<?= base_url('User/logout'); ?>"><i class="fas fa-sign-out-alt"></i> Log Out</a>
			</div>
	</div>
	<hr>
		<div class='row' style="height:86%;">

			<div class='col-sm-3 border-right border-dark'>
				<?php include 'side_nav_bar.php'; ?>
			</div>
			
			<div class='col-sm'>
				<img src="<?= base_url('tool/img/libry.jpg') ?>" alt="Books in Library" width='300px'/>
				<p>
				A college library management is a project that manages and stores books information electronically according to students needs.
				The system helps both students and library manager to keep a constant track of all the books available in the library. It allows 
				both the admin and the student to search for the desired book. It becomes necessary for colleges to keep a continuous check on the
				books issued and returned and even calculate fine. <br>          This task if carried out manually will be tedious and includes chances of mistakes.
				These errors are avoided by allowing the system to keep track of information such as issue date, last date to return the book and even 
				fine information and thus there is no need to keep manual track of this information which thereby avoids chances of mistakes.
				</p>
			</div>
		</div>
	</div>        

<?php include('footer.php'); ?>
