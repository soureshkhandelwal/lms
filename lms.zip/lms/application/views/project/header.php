<!DOCTYPE html>
<html>
<head>
	<title>Library Managment System</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('tool/css/bootstrap.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('tool/css/style.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('tool/DataTables/css/jquery.dataTables.min.css'); ?>">

	<script type="text/javascript" src="<?php echo base_url('tool/js/jquery.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('tool/js/bootstrap.js'); ?>"></script>
	<script src="https://kit.fontawesome.com/90b368f95f.js" crossorigin="anonymous"></script>
    <script type="text/javascript" charset="utf8" src="<?php echo base_url('tool/DataTables/js/jquery.dataTables.js'); ?>"></script>

</head>
<body class='banner'>
	<div class="container-fluid header">
		<div class='container'>
			<h1 class='text-center bg-dark p-1'>Library Management System</h1>
		</div>
	</div>