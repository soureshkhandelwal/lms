<?php include('header.php'); ?>

	<div class='container'>
		<div class='inner'>
			<h2 class='text-center font-weight-bold mb-4'>Admin Login</h2>
			<div class='row'>
				<div class='col-sm-10 offset-sm-1'>
					<table class='table'>
						<tbody><tr>
							<td class='text-white'><b>Username</b></td>
							<td>                 
								<input type='text' name='un' id="un" placeholder='Enter Password' class='form-control'>
		                	</td>
						</tr>
						<tr>
							<td class='text-white'><b>Password</b></td>
							<td> <input type='Password' name='psw' id="psw" placeholder='Enter Password' class='form-control'></td>
						</tr>
						<!-- <tr>
							<td></td>
							<td class='text-white'> <input type='checkbox' name='c1'> Remember me</td>
						</tr> -->
						<tr>
							<td></td>
							<td><button type='submit' class='btn btn-warning' id="login_btn">Login</button></td>
						</tr>
						</tbody>
					</table>
				</div>

				<div class='col-sm-1'></div>
			</div>

		</div>
	</div>

<script type="text/javascript">
	
	$(document).ready(function()
	{
		$('#login_btn').click(function(e)
		{
			e.preventDefault();

			var name = $('#un').val();
			var pass = $('#psw').val();

			data = {'user':name, 'pass':pass};

			$.ajax({
					url : "<?php echo base_url('User/login'); ?>",
					method:'post',
					data:data,
					success:function(resp)
					{
						// alert(resp);
						if(resp==1)
						{
							console.log(resp)
							window.open("<?php echo base_url('Home/dashboard'); ?>",'_self');
						}
						else
							alert("Username or Password or Both do not match");
					}
			})
		})
	})

</script>
<?php include('footer.php'); ?>