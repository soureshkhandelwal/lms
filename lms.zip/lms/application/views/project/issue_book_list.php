<?php 
	define('Title','Issued Books');
	define('active_nav', 'Book Issue & Submit');
?>

<?php include('header.php'); ?>

	<div class='container mt-2' style="opacity:0.7;height:100%;box-shadow:1px 1px 5px 5px black;background-color: lightblue">
		<h1 class='display-5'>Welcome (<?php echo $this->session->userdata('username') ?>) </h1>  <hr>
		<div class='row'>
			<div class='col-sm-3 border-right border-dark'>
				<?php include 'side_nav_bar.php'; ?>
			</div>
			<div class='col-sm' style="height:auto;">
				<div class="row">
					<div class="col-2">
						<a class="btn btn-danger" href="<?= base_url('home/issue_submit'); ?>">Back</a>
					</div>
					
					<div class="col-6">
						<h4 class='text-center text-dark' style="font-size:28px;"><b><?php echo Title; ?></b></h4>		
					</div>

					<div class="col offset-1">
						<a class="btn btn-secondary" href="<?= base_url('home/submitted_book_list'); ?>"><i class="fas fa-list"></i> Submitted Book List</a>
					</div>

				</div>
				<hr>
				
				<table class='table table-hover table-sm' id="issued_booklist_table">
					<thead>
						<tr><th>S.No.</th>
							<th>User-Id</th>
							<th>Name</th>
							<th>Book-Name</th>
							<!-- <th>Address</th> -->
							<th>Email</th>
							<th>Operations</th>
						</tr>
					</thead>

					<tbody>
					<?php  
					if(isset($data))
					{	
						$i=1;	
						// echo '<pre>';
						// print_r($data); die();
						foreach($data as $issueBook)
						{
					?>
						<tr>
							<td><?php echo $i; ?></td>
							<td><?php echo $issueBook['user_id'] ?></td>
							<td><?php echo $issueBook['name'] ?></td>
							<td><?php echo $issueBook['book_name'] ?></td>
							<!-- <td><?php echo $issueBook['address'] ?></td> -->
							<td><?php echo $issueBook['email'] ?></td>
							<td><a href="<?= base_url('home/submit_book/'.$issueBook['id']) ?>" class="btn btn-secondary" name="submit_book">SUBMIT</a></td>
						</tr>
                    <?php  
                    	$i++;
                    	}
                    }
                    ?>
					</tbody>
				</table>

				<?php  
				if(!empty($this->session->flashdata('msg')))
				{
					$msg=$this->session->flashdata('msg');
					$cls=$this->session->flashdata('class_name');
				?>
					<div class="row">
						<div class="col font-weight-bold alert <?= $cls ?>"><?= $msg; ?></div>
					</div>
				<?php	
				}

				?>	
	</div>        

	<script type="text/javascript">
		$('#issued_booklist_table').DataTable({
			"lengthMenu": [[5, 10, 15, 20, -1],[5, 10, 15, 20, "ALL"]]
		});
	</script> 

<?php include('footer.php'); ?>
