<?php 
	define('Title','Add Member');
	define('active_nav', 'Book Issue & Submit');
?>
<?php include('header.php'); ?>

	<div class='container mt-2' style="opacity:0.7;height:100%;box-shadow:1px 1px 5px 5px black;background-color: lightblue">
		<h1 class='display-5'>Welcome (<?php echo $this->session->userdata('username') ?>) </h1>  <hr>

		<div class='row' style="height:500px;">
			<div class='col-sm-3 border-right border-dark'>
				<?php include 'side_nav_bar.php'; ?>
			</div>
			<div class='col-sm' style="height: auto;">
				<div class="row">
					<div class="col-3">
						<a class="btn btn-warning" href="<?= base_url('home/submitted_book_list'); ?>">Submitted-Book</a>
					</div>

					<div class="col-4">
						<h4 class='text-center text-dark' style="font-size:28px;"><b><?php echo Title; ?></b></h4>				
					</div>

					<div class="col-3  offset-2">
						<a class="btn btn-secondary" href="<?= base_url('home/issue_book_list'); ?>"><i class="fas fa-list"></i> Issued Book List</a>
					</div>
				</div>
				<hr>
				<!-- <?php if(isset($data['id'])) echo $data['id']?> -->
			
				<?php echo form_open('Home/book_filter'); ?>
				<table class='table table-sm'>
					<tr>
						<td><b>Member ID</b></td>
						<td><input type='text' name='id' id="user_id" value="<?php if(isset($userid)) echo $userid ?>" class='form-control' placeholder="Enter User Id"></td>
						<td><input type='submit' name='search_id' class='btn btn-danger' value='Search'></td>
					</tr>
				</table> 
				<?php echo form_close(); ?>

				<?php 
					// print_r($error);
					// exit();
					if(isset($data))
					{
						// print_r($data);
				?>
					<?php echo form_open('Home/issue_book'); ?>
						<table class="table table-sm">
							<tr>
								<td><b>ID</b></td>
								<td><input type='text' name='user_id' value="<?php echo $data['id']?>" class='form-control' readonly='true'></td> 

								<td><b>Name</b></td>
								<td><input type='text' name='name' readonly='true' id="name" value="<?php echo $data['name']?>" class='form-control'></td>
							</tr>
							<tr>
								<td><b>Address</b></td>
								<td><input type='textarea' name='address' readonly='true' id="adrs" value="<?php echo $data['address']?>" class='form-control'></td> 

								<td><b>Email-Id</b></td>
								<td><input type='text' name='email' id="mail" readonly='true' value="<?php echo $data['email']?>" class='form-control'></td>
							</tr>
							<tr>
								<td><b>Book Name</b></td>
								<td>
									<select name="book_name" class="form-control">
									<?php 
									if(isset($book_list))
									{
										// print_r($book_list)
										foreach($book_list as $book_data)
										{										
									?>
											<option><?php echo $book_data['book_name']; ?></option>
									<?php  
										}
									}
									?>
									</select>
								</td>
							</tr>
							<tr>
								<td>
									<button type="submit" class="btn btn-info">Book Now</button>
								</td>
							</tr>
						</table>
					<?php echo form_close(); ?>

				<?php 
					}
					else
					{
						$msg=$this->session->flashdata('msg');
						$cls=$this->session->flashdata('class_name');
				?>
						<div class="row">
							<div class="col-7 offset-3 font-weight-bold alert <?php echo $cls; ?>"><?php echo $msg; ?></div>
						</div>
						<script type="text/javascript">
							$('#user_id').focus();
						</script>
				<?php
					}
				?>
			</div>
		</div>
	</div>        

<?php include('footer.php'); ?>
