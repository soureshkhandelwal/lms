<?php 
	define('Title', 'Members List');
	define('active_nav', 'Member');
?>
<?php include('header.php'); ?>

	<div class='container mt-2' style="opacity:0.7;height:100%;box-shadow:1px 1px 5px 5px black;background-color: lightblue">
		<div class="row">
			<div class="col-5">
				<h1 class='display-5'>Welcome <?php echo $this->session->userdata('username') ?></h1>				
			</div>
			<div class="col offset-5 mt-3">
				<a class="btn btn-warning" href="<?= base_url('User/logout'); ?>"><i class="fas fa-sign-out-alt"></i> Log Out</a>
			</div>
		</div>

		<hr>

		<div class='row' style=" height:500px;">
			<div class='col-sm-3 border-right border-dark'>
				<?php include 'side_nav_bar.php'; ?>
			</div>
		
			<div class='col-sm' style=" height:auto;">
				<div class="row mt-2">
					<div class="col-3">
						<a class="btn btn-outline-danger" href="<?= base_url('home/add_member'); ?>"><i class="fas fa-plus"></i> Add Member</a>
					</div>
					<div class="col-4">
						<h4 class='text-center'><b><?php echo Title; ?></b></h4>				
					</div>
				</div>
				<hr>

				<table class='table' style="width: 800px;" id="member_table">
					<thead>
						<tr>
							<th>S.No.</th>
							<th>Name</th>
							<!-- <th>Address</th> -->
							<th>Email</th>
							<th>Mobile</th>
						</tr>
					</thead>
				</table>
			</div>

		</div>
	</div> 

	<script type="text/javascript">
		$('#member_table').DataTable({
			"ajax": "<?php echo base_url('Home/show_member_list'); ?>",
			"order": [],
			"lengthMenu": [[5, 10, 15, 20, -1],[5, 10, 15, 20, "ALL"]],
		});
	</script>       

<?php include('footer.php'); ?>
