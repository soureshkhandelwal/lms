<?php 
	define('Title','Generate Report');
	define('active_nav', 'Report');
?>
<?php include('header.php'); ?>

	<div class='container mt-2' style="opacity:0.7;height:100%;box-shadow:1px 1px 5px 5px black;background-color: lightblue;">
	<div class="row">
			<div class="col-5">
				<h1 class='display-5'>Welcome (<?php echo $this->session->userdata('username') ?>) </h1>				
			</div>
			<div class="col offset-5 mt-3">
				<a class="btn btn-warning" href="<?= base_url('User/logout'); ?>"><i class="fas fa-sign-out-alt"></i> Log Out</a>
			</div>
	</div>
	<hr>
		<div class='row' style="height:86%;">

			<div class='col-sm-3 border-right border-dark'>
				<?php include 'side_nav_bar.php'; ?>
			</div>
			
			<div class='col-sm'>
                <div class='row'>
	            	<div class='form-group col-sm-2'>
	                    <label for='generate_rep' style="font-size:17px;"><b>Select: </b></label>
	                </div>
	                <div class='form-group col-sm-5'>
						<select name='generate_rep' id='generate_rep' class='form-control'>
							<option value="" selected readonly='true'>--Select--</option>
                            <option value="author">Author</option>
                            <option value="publisher">Publisher</option>
						</select>
					</div>
		        </div>
			<!-- </div> --><br>
		
			<!-- <div class='row'> -->
				<table class='table table-sm' style="width:400px;" id="report_table">
						<thead>
							<tr>
								<th>S.No.</th>
								<th>Name</th>
								<th>Book_Name</th>
							</tr>
						</thead>
						<tbody>
							
						</tbody>
				</table>
			</div>
		</div>
		
	</div>     

	<script type="text/javascript">

		$('#generate_rep').change(function()
		{
			var rep_val=$('#generate_rep').val()+'_name';
			console.log(rep_val);

			$.ajax({
					url: "<?php echo base_url('Home/get_report_info') ?>",
					type:'POST',
					data:{name:rep_val},
					dataType: 'JSON',
					success:function(data)
							{
								console.log(data)
								$('#report_table').DataTable({
									// data:data,
									// 'columns':[
									// 	{ 'data': 'i' },
									// 	{ 'data': 'name' },
									// 	{ 'data': 'book_name' }
											// ],
									"order": [],
									"lengthMenu": [[5, 10, 15, 20, -1],[5, 10, 15, 20, "ALL"]],
								})

								
			// 					$('tbody').html('')
			// 					console.log(data)
			// 					$.each(data,function(key,value)
			// 					{
			// 						// console.log(value.name+' -> '+value.book_name)
			// 						var html='<tr> <td>'+(key+1)+'</td> <td>'+value.name+'</td> <td>'+value.book_name+'</td> </tr>';
			// 						$('tbody').append(html);
			// 					})
							}
			})

			// $('#report_table').DataTable().ajax.reload(); 

			// $('#report_table').DataTable({
			// 			"processing": true,
			// 		    "serverSide": true,
			// 		    "bDestroy": true,
			// 		    "bJQueryUI": true,
			// 			"ajax":{
			// 						'type': 'POST',
			// 						'url' : "<?php echo base_url('Home/get_report_info') ?>",
			// 						'data': {  name: rep_val },
			// 					},
			// 			"order": [],
			// 			"lengthMenu": [[5, 10, 15, 20, -1],[5, 10, 15, 20, "ALL"]],
			// });
		})

			// $('#report_table').DataTable();


	</script>

<?php include('footer.php'); ?>
   