<nav class='nav flex-column nav-pills'>
     <a  href="<?= base_url('home/dashboard'); ?>" 
    	class='nav-link text-success font-weight-bold p-3 <?php if(active_nav=="Dashboard"){ echo "active"." text-warning";} ?>'>Dashboard</a>

    <a href="<?= base_url('home/book_stock'); ?>" 
    class='nav-link text-success font-weight-bold p-3 <?php if(active_nav=="Book Stock Manage"){ echo "active"." text-warning";} ?>'>Book Stock Manage</a>

    <a href="<?= base_url('home/issue_submit'); ?>"
     class='nav-link text-success font-weight-bold p-3 <?php if(active_nav=="Book Issue & Submit"){ echo "active"." text-warning";} ?>'>Book Issue & Submit</a>

    <a href="<?= base_url('home/members'); ?>"
       class='nav-link text-success font-weight-bold p-3 <?php if(active_nav=="Member"){ echo "active"." text-warning";} ?>'>Members</a>

   <a href="<?= base_url('home/gen_report'); ?>"
       class='nav-link text-success font-weight-bold p-3 <?php if(active_nav=="Report"){ echo "active"." text-warning";} ?>'>Reports</a>
</nav>