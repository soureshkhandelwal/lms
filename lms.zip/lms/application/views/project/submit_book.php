<?php 
	define('Title','Submit Book');
	define('active_nav', 'Book Issue & Submit');
?>
<?php include('header.php'); ?>

	<div class='container mt-2' style="opacity:0.7;height:100%;box-shadow:1px 1px 5px 5px black;background-color: lightblue">
		<h1 class='display-5'>Welcome (<?php echo $this->session->userdata('username') ?>) </h1>  <hr>
		<div class='row' style="height: 400px;">
			
			<div class='col-sm-3 border-right border-dark'>
				<?php include 'side_nav_bar.php'; ?>
			</div>
			
			<div class='col-sm' style="height:auto;">
				<div class="row">				
					<div class="col-6 offset-2">
						<h4 class='text-center text-dark' style="font-size:28px;"><b><?php echo Title; ?></b></h4>				
					</div>

					<div class="col-3  offset-1">
						<a class="btn btn-secondary" href="<?= base_url('home/issue_book_list'); ?>">Issued Book-List</a>
					</div>
				</div>
				<!-- <hr> -->
				
				<table class="table table-sm mt-3">
					<tr>
						<td><b>Member-ID</b></td>
						<td><input type='text' name='mem_id' id="mem_id" placeholder="Enter ID" class='form-control'></td> 

						<td><b>Member-Name</b></td>
						<td><input type='text' name='mem_name' id="mem_name" placeholder="Enter Member Name" class='form-control'></td>
					</tr>
					<tr>
						<td><b>Address</b></td>
						<td><input type='text' name='mem_adrs' id="mem_adrs" placeholder="Enter Address" class='form-control'></td> 

						<td><b>Email-Id</b></td>
						<td><input type='text' name='mem_mail' id="mem_mail" placeholder="Enter Member Email Id" class='form-control'></td>
					</tr>
					<tr>
						<td><b>Book Name</b></td>
						<td><input type='text' name='bookname' id="bookname" placeholder="Enter Book Name" class='form-control'></td> 

						<td><b>Price</b></td>
						<td><input type='text' name='bookprice' id="price" placeholder="Enter Book Price" class='form-control'></td>
					</tr>
					<tr colspan="4">
						<td>
							<button class="btn btn-info">Submit Book</button>
						</td>
					</tr>
				</table>
			</div>
		</div>
	</div>        

<?php include('footer.php'); ?>
